// variable used to hold data
var workDetails=
    {"Job":"Job:Trainee Solicitor",
     "Location":"Location: O'Brien & Associates",
     "Dates":"Dates: 2018 to present",
	 "spacer":"", 
	 "Job2":"Job:Bar Supervisor",
     "Location2":"Location: Alfie's Bar and Kitchen",
     "Dates2":"Dates: 2017-2018",
	 "spacer2":"", 
	 "Job3":"Job:Senior Barman",
     "Location3":"Location: Dunraven Arms Hotel",
     "Dates3":"Dates: 2012-2016"}
	 
	 // for loop used to output to element by id		
for (var i in workDetails ) {
document.getElementById("myContactDetails").innerHTML +=workDetails[i] + "<br>"; 
}








