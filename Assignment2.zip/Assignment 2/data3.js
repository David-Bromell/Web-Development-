// output to projects section 
var Projects = 
{
"No1": "Project 1)Use of Artifical neural networks in finanial analysis & regulation",
"spacer":"", 
"No2": "Project 2)Training methods of artifical neural networks",
"spacer2":"", 
"No3":" Project 3)Applications of blockchain to legal technology"
													}
// for loop used to output to element by id													
for (var y in Projects ) {
document.getElementById("myProjectDetails").innerHTML +=Projects[y] + "<br>"; 
}