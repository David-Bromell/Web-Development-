//variable used to hold data

var Education = 
    {"Location":"NUIG",
     "Dates":"2014-2018",
	 "Course" :"Corporate Law & Legal French",
	 "spacer":"", 
	 "Locatio2":"Universite de Poitiers",
     "Date2":"2017-2018",
	 "Cours2" :"Civil Law",
	  "space2":"", 
	 "Location4":"UL",
     "Dates4":"2018-2020",
	"Course3" :"MSc Software Development"}
	
	// for loop used to output to element by id		
for (var y in Education ) {
document.getElementById("myEducationDetails").innerHTML +=Education[y] + "<br>"; 
}


