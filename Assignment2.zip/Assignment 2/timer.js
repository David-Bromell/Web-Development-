	
	// variable time created  with setInterval method so we can use clear interval metho below
	var time = setInterval(RandomDiv,30000); 
	
	// creates an array of divs used for holding information, then uses math.floor in order to make sure awhole index number is returned, next math.random is used to select a ranom div andthis is multiplied by the number of divs to ensure it cant go anyhigher than the number of divs in the array
	function RandomDiv() {
    var divs= new Array("myDIV","myDIV2","myDIV3");
    var randomDiv = divs[Math.floor(Math.random() * divs.length)];
    document.getElementById(randomDiv).style.display="block";
} 

// stop function, time variable as set out above use here with clear interval method
function stop () {
	  clearInterval(time);
	}