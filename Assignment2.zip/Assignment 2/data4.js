// sets slide to slide  1 
var slide = 1;
//passes slide to showdivs function 
showDivs(slide);


// arrow functionality to go back and forth 
function cycleDiv(y) {
  showDivs(slide = y + slide);
}
// constantly allows the divs to be displayed on arrow click 
function showDivs(y) {
 // gets element by the name of class and lets it equal to x
  var x = document.getElementsByClassName("mySlides");
  // if y is greater tha the length of myslides , the slide index is set as 1
  if (y > x.length) {slide = 1} 
  // if y is less than the 1, the slide index is set as 1
  if (y < 1) {slide = x.length} ;
  // for loop use to cycle through 
  for (var i = 0; i < x.length; i++) {
	  // ensures one is displayed at a time
    x[i].style.display = "none"; 
  }
  // displays the pictures a block level element 
  x[slide-1].style.display = "block"; 
}


 