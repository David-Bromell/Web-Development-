
var width=640;
var height=320;



  var xpositions=[];
  var ypositions=[];
  var xdirs=[];
  var ydirs=[];
  
  // Create arrays
  

  for (var i = 0 ; i <totalSize; i++)
     {
	 xpositions.push( width/2);
	 ypositions.push( height/2);
	 xdirs.push(Math.random()* 2);
	 ydirs.push(Math.random()*1);
	 // Set up position
	 var myElemName="anim" + i;
         document.getElementById("container").innerHTML+="<div id ='" + myElemName + "' class='animated' ><img src=ball.png></div>"; 
	 var elem = document.getElementById(myElemName); 

	 elem.style.top = ypositions[i] + "px"; 
	elem.style.left = xpositions[i] + "px";
}			 



// Create the divs

  
var rad = 60;        // Width of the shape
var xpos, ypos;    // Starting position of shape    

var xspeed = 4.8;  // Speed of the shape
var yspeed = 4.2;  // Speed of the shapevar xdirection = 1;  // Left or Right
var ydirection = 1;  // Top to Bottom
var  xpos = width/2;
var  ypos = height/2;



function myMove2()
{
      

  var id = setInterval(frame, 30);
  function frame() {
      for (var i=0;i<totalSize;i++)
      {
	  var myElemName="anim" + i;
	  //console.log(myElemName);
	  var elem = document.getElementById(myElemName); 
    // Update the position of the shape
  xpositions[i] = xpositions[i] + ( xspeed * xdirs[i] );
  ypositions[i] = ypositions[i] + ( yspeed * ydirs[i] );
  
  // Test to see if the shape exceeds the boundaries of the screen
  // If it does, reverse its direction by multiplying by -1
  if (xpositions[i] > width-rad || xpositions[i] < 1) {
    xdirs[i] *= -1;
  }
  if (ypositions[i] > height-rad || ypositions[i] < 1) {
    ydirs[i] *= -1;
  }
      elem.style.top = ypositions[i] + "px"; 
	elem.style.left = xpositions[i] + "px";
	  //console.log(elem);
      }

				  
  }
}


function myMove3()
{
    var elem = document.getElementById("anim1");   

  var id = setInterval(frame, 60);
  function frame() {

  // Update the position of the shape
  xpos += xpos + ( xspeed * xdirection+1 );
  ypos -= ypos + ( yspeed * ydirection-2 );
  
  // Test to see if the shape exceeds the boundaries of the screen
  // If it does, reverse its direction by multiplying by -1
  if (xpos > width-rad || xpos < 1) {
    xdirection *= -1;
  }
  if (ypos > height-rad || ypos < 1) {
    ydirection *= -1;
  }
      elem.style.top = ypos + "px"; 
      elem.style.left = xpos + "px"; 

				  }}


