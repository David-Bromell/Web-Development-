function getCard(cardVal,suitVal)
{
var result="<img  class='field-item even' width=100 src=Cards/";
   switch(cardVal)
   {
     case 0: result += "2_of_";break;
     case 1: result += "3_of_";break;
     case 2: result += "4_of_";break;
     case 3: result += "5_of_";break;
     case 4: result += "6_of_";break;
     case 5: result += "7_of_";break;
     case 6: result += "8_of_";break;
     case 7: result += "9_of_";break;
     case 8: result += "10_of_";break;
     case 9: result += "ace_of_";break;
     case 10: result += "jack_of_";break;
     case 11: result += "queen_of_";break;
     case 12: result += "king_of_";break;
}
   switch(suitVal)
   {
     case 0: result += "hearts.png>";break;
     case 1: result += "clubs.png>";break;
     case 2: result += "spades.png>";break;
     case 3: result += "diamonds.png>";break;
}
return result;
}


function getHand(numCards)
{
    document.getElementById("hand").innerHTML="";
    for (let i=0;i<numCards;i++)
    {
	cardVal=Math.floor(Math.random()*13);
	suitVal=Math.floor(Math.random()*4);
	myhand=getCard(cardVal,suitVal) ;
	document.getElementById("hand").innerHTML+=myhand ;
	
    }
    
}



function newCard(numCards) {
	
	   document.getElementById("hand").innerHTML="";
    for (let i=0;i<numCards;i++)
    {
	cardVal=Math.floor(Math.random()*13);
	suitVal=Math.floor(Math.random()*4);
	myhand=getCard(cardVal,suitVal) + myhand;
	document.getElementById("hand").innerHTML+=myhand;
	
	
	
    }
    
}

