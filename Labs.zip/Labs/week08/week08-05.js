for(i=1; i<10;i++) {
   
    var element = document.createElement("div");
    element.createElement = "row" + i;
	element.setAttribute("id", "row"+i);
    document.getElementById('results').appendChild(element);
    

}






function addSquare(myID,myRow,squareSize)
  {
  idToUse="square"+myID;
  console.log(idToUse);
  

  // This time we use the myRow parameter to identify which row to use
  // Note that now the colour is generated at random
  document.getElementById(myRow).innerHTML+=
        "<div id='" + idToUse + "' style='background:" + getRandomColour() + "; width:" +squareSize + "px; height:" + squareSize + "px; background='red'> </div>"
											 
  }


function getRandomColour() {
  var letters = '0123456789ABCDEF';
  var color = '#';
  for (var i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
}
	
for (i = 1; i<10; i++){
		addSquare(i,"row1",100);
		addSquare(i,"row2",100);
		addSquare(i,"row3",100);
		addSquare(i,"row4",100);
		addSquare(i,"row5",100);
		addSquare(i,"row6",100);
		addSquare(i,"row7",100);
		addSquare(i,"row8",100);
		addSquare(i,"row9",100);
}


  


