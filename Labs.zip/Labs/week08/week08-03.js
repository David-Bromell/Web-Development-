
for (let i=1;i<11;i++) {
    document.getElementById("results").innerHTML += "myRes" +  i + " ";
	}

