for(i=1; i<10;i++) {
   
    var element = document.createElement("div");
    element.createElement = "row" + i;
	element.setAttribute("id", "row"+i);
    document.getElementById('results').appendChild(element);
    

}