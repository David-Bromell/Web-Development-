for (let i=0;i<5;i++) {
    console.log("Output goes here", i);
	}