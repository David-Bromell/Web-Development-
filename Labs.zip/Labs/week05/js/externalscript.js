
status = 1;
function changeStyle() {


x = document.getElementById("changeText");

if(status==1) {
    x.style.color = 'blue';

}